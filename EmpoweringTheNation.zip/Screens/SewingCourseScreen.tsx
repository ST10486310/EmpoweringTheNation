import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Linking
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

export default function SewingCourseScreen({ navigation }) {
  const courseContent = [
    'Types of stitches',
    'Threading a sewing machine',
    'Sewing buttons, zips, hems and seams',
    'Alterations',
    'Designing and sewing new garments'
  ];

  const courseBenefits = [
    'Hands-on sewing machine training',
    'Professional alteration techniques',
    'Pattern reading and creation',
    'Fabric selection and handling',
    'Business skills for tailoring services',
    'Portfolio development'
  ];

  const handleEnroll = () => {
    
    Linking.openURL('tel:+1234567890'); 
  };

  return (
    <ScrollView style={styles.container}>
      {/* Course Header */}
      <View style={styles.courseHeader}>
        <View style={styles.iconContainer}>
          <Ionicons name="cut" size={40} color="#fff" />
        </View>
        <Text style={styles.courseTitle}>Sewing</Text>
        <Text style={styles.courseSubtitle}>
          Master the art of sewing
        </Text>
      </View>

      {/* Course Details */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Course Overview</Text>
        
        <View style={styles.priceContainer}>
          <Text style={styles.price}>R1500</Text>
          <Text style={styles.priceNote}>including basic materials</Text>
          <Text style={styles.paymentPlan}>or 3 payments of R500</Text>
        </View>

        <View style={styles.infoCard}>
          <Text style={styles.infoTitle}>Purpose</Text>
          <Text style={styles.infoText}>
            To provide skills in alterations and new garment tailoring services, 
            enabling students to create, modify, and repair clothing professionally.
          </Text>
        </View>
      </View>

      {/* Course Content */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Course Content</Text>
        <View style={styles.contentCard}>
          {courseContent.map((item, index) => (
            <View key={index} style={styles.contentItem}>
              <Ionicons name="checkmark" size={20} color="#4AAA55" />
              <Text style={styles.contentText}>{item}</Text>
            </View>
          ))}
        </View>
      </View>

      {/* Course Benefits */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Course Benefits</Text>
        <View style={styles.benefitsCard}>
          {courseBenefits.map((benefit, index) => (
            <View key={index} style={styles.benefitItem}>
              <Ionicons name="star" size={16} color="#4FB7B3" />
              <Text style={styles.benefitText}>{benefit}</Text>
            </View>
          ))}
        </View>
      </View>

      {/* Additional Info */}
      <View style={styles.section}>
        <View style={styles.infoGrid}>
          <View style={styles.infoItem}>
            <Ionicons name="time" size={24} color="#4AAA55" />
            <Text style={styles.infoItemTitle}>Duration</Text>
            <Text style={styles.infoItemText}>6-month course</Text>
          </View>
          
          <View style={styles.infoItem}>
            <Ionicons name="business" size={24} color="#4AAA55" />
            <Text style={styles.infoItemTitle}>Materials</Text>
          </View>
        </View>

         
      </View>

      {/* Enrollment Section */}
      <View style={styles.enrollmentSection}>
        <TouchableOpacity style={styles.enrollButton} onPress={handleEnroll}>
          <Text style={styles.enrollButtonText}>Enroll Now - R1500</Text>
        </TouchableOpacity>
        
        <View style={styles.paymentOptions}>
          <View style={styles.paymentBadges}>
            <View style={styles.paymentBadge}>
              <Text style={styles.paymentBadgeText}>Full Payment: R1500</Text>
            </View>
             
          </View>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#DDF4E7',
  },
  courseHeader: {
    backgroundColor: '#4AAA55',
    padding: 24,
    alignItems: 'center',
  },
  iconContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  courseTitle: {
    fontFamily: 'Montserrat-SemiBold',
    fontSize: 24,
    color: '#fff',
    textAlign: 'center',
    marginBottom: 8,
  },
  courseSubtitle: {
    fontFamily: 'IstokWeb-Regular',
    fontSize: 16,
    color: '#fff',
    textAlign: 'center',
    opacity: 0.9,
    marginBottom: 12,
  },
  courseCode: {
    backgroundColor: 'rgba(255,255,255,0.2)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  courseCodeText: {
    fontFamily: 'IstokWeb-Regular',
    fontSize: 12,
    color: '#fff',
    fontWeight: 'bold',
  },
  section: {
    padding: 20,
  },
  sectionTitle: {
    fontFamily: 'Montserrat-SemiBold',
    fontSize: 20,
    color: '#333',
    marginBottom: 16,
  },
  priceContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  price: {
    fontFamily: 'Montserrat-SemiBold',
    fontSize: 32,
    color: '#4AAA55',
  },
  priceNote: {
    fontFamily: 'IstokWeb-Regular',
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  paymentPlan: {
    fontFamily: 'IstokWeb-Regular',
    fontSize: 14,
    color: '#4FB7B3',
    fontWeight: 'bold',
    marginTop: 2,
  },
  infoCard: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  infoTitle: {
    fontFamily: 'Montserrat-SemiBold',
    fontSize: 18,
    color: '#4AAA55',
    marginBottom: 8,
  },
  infoText: {
    fontFamily: 'IstokWeb-Regular',
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
  },
  contentCard: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  contentItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  contentText: {
    fontFamily: 'IstokWeb-Regular',
    fontSize: 14,
    color: '#333',
    marginLeft: 8,
    flex: 1,
    lineHeight: 20,
  },
  benefitsCard: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  benefitItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  benefitText: {
    fontFamily: 'IstokWeb-Regular',
    fontSize: 14,
    color: '#333',
    marginLeft: 8,
    flex: 1,
  },
  infoGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  infoItem: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    width: '48%',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  infoItemTitle: {
    fontFamily: 'Montserrat-SemiBold',
    fontSize: 14,
    color: '#333',
    marginTop: 8,
    marginBottom: 4,
  },
  infoItemText: {
    fontFamily: 'IstokWeb-Regular',
    fontSize: 12,
    color: '#666',
    textAlign: 'center',
  },
  additionalInfo: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  additionalInfoTitle: {
    fontFamily: 'Montserrat-SemiBold',
    fontSize: 16,
    color: '#4AAA55',
    marginBottom: 8,
  },
  additionalInfoText: {
    fontFamily: 'IstokWeb-Regular',
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
  },
  enrollmentSection: {
    padding: 20,
    paddingTop: 0,
  },
  enrollButton: {
    backgroundColor: '#4FB7B3',
    paddingVertical: 16,
    borderRadius: 30,
    alignItems: 'center',
    marginBottom: 16,
  },
  enrollButtonText: {
    fontFamily: 'Montserrat-SemiBold',
    fontSize: 18,
    color: '#000',
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  paymentOptions: {
    alignItems: 'center',
    marginBottom: 16,
  },
  paymentOptionText: {
    fontFamily: 'IstokWeb-Regular',
    fontSize: 14,
    color: '#666',
    marginBottom: 8,
  },
  paymentBadges: {
    flexDirection: 'row',
    justifyContent: 'center',
    flexWrap: 'wrap',
  },
  paymentBadge: {
    backgroundColor: '#f0f9f0',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    marginHorizontal: 4,
    marginBottom: 4,
  },
  paymentBadgeText: {
    fontFamily: 'IstokWeb-Regular',
    fontSize: 12,
    color: '#4AAA55',
    fontWeight: 'bold',
  },
  contactButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
  },
  contactButtonText: {
    fontFamily: 'IstokWeb-Regular',
    fontSize: 16,
    color: '#4FB7B3',
    marginLeft: 8,
    fontWeight: 'bold',
  },
});